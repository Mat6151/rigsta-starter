# Rigsta Starter (Free)

A zero-cost starter for **Rigsta** you can host on **Glitch**:
- PWA (installable, offline)
- Basic AR capability check (WebXR)
- Simple load & angle calculator
- Express server for Glitch

## Run locally
```
npm install
npm start
```

Then open http://localhost:3000

## Deploy to Glitch
Create a new Glitch project → Upload these files → It will run automatically.

Build date: 2025-10-30
