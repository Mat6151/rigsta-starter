// Rigsta Starter App — vanilla JS SPA + PWA + AR capability check + simple load calculator
const app = document.getElementById('app');
document.getElementById('year').textContent = new Date().getFullYear();

const views = {
  home: () => `
    <section class="card">
      <h2>Welcome to Rigsta (Starter)</h2>
      <p>Free starter app you can host on Glitch. It includes:</p>
      <ul>
        <li>✅ PWA (installable + offline caching)</li>
        <li>✅ Basic AR capability check (WebXR)</li>
        <li>✅ Simple load & angle calculator</li>
        <li>✅ Clean layout ready for Firebase (optional)</li>
      </ul>
      <p>Use the <b>Tools</b> tab to try the calculator, and <b>AR</b> tab to test WebXR support.</p>
    </section>
    <section class="grid">
      <div class="kpi"><h3>PWA</h3><p>Install via your browser menu (Add to Home Screen).</p></div>
      <div class="kpi"><h3>Offline</h3><p>Open this app once online; it will also work offline.</p></div>
      <div class="kpi"><h3>AR</h3><p>Uses WebXR if your device/browser supports it.</p></div>
      <div class="kpi"><h3>Free</h3><p>Host on Glitch — no cost, no credit card.</p></div>
    </section>
  `,
  tools: () => `
    <section class="card">
      <h2>Load & Angle Calculator (Demo)</h2>
      <div class="grid">
        <div>
          <label>Total Load (kg)</label>
          <input id="load" type="number" min="0" step="0.1" value="1000">
        </div>
        <div>
          <label>Number of Sling Legs (n)</label>
          <select id="legs">
            <option>1</option>
            <option selected>2</option>
            <option>3</option>
            <option>4</option>
          </select>
        </div>
        <div>
          <label>Angle from Horizontal (degrees)</label>
          <input id="angle" type="number" min="0" max="89" step="1" value="45">
        </div>
      </div>
      <p><button class="calc" id="calc">Calculate</button></p>
      <div id="result" class="card"></div>
      <p style="font-size:12px;color:#9dc7da">This is a simplified educational demo. Always follow your organization's standards.</p>
    </section>
  `,
  ar: () => `
    <section class="card">
      <h2>AR Capability Check</h2>
      <p>This starter checks if your browser supports <b>WebXR</b> (for AR). Use Chrome/Android or newer iOS Safari (with WebXR support).</p>
      <div id="xrStatus" class="card"></div>
      <h3>What next?</h3>
      <ul>
        <li>If supported: you can add a "Enter AR" button later using Three.js' WebXR.</li>
        <li>If not supported: the app will still work as a normal PWA.</li>
      </ul>
      <pre class="code">
// Example: quick feature check (also done automatically)
if (navigator.xr && navigator.xr.isSessionSupported) {
  const ok = await navigator.xr.isSessionSupported('immersive-ar');
  console.log('AR supported?', ok);
}
      </pre>
    </section>
  `,
  offline: () => `
    <section class="card">
      <h2>Offline Mode</h2>
      <p>This PWA caches core files so Rigsta works even without internet.</p>
      <ul>
        <li>Try: Open this page online once, then go offline and refresh.</li>
        <li>You'll still see the app (cached).</li>
      </ul>
    </section>
  `,
  about: () => `
    <section class="card">
      <h2>About This Starter</h2>
      <p>Use this as a foundation. Add pages, connect Firebase, and grow features.</p>
      <p><b>Files:</b> index.html, app.js, styles.css, sw.js, manifest.webmanifest, server.js</p>
    </section>
  `
};

function render(view='home'){
  app.innerHTML = views[view]();
  if(view==='tools'){
    const $ = (id)=>document.getElementById(id);
    const load = $('load'), legs=$('legs'), angle=$('angle'), res=$('result'), btn=$('calc');
    const calc = ()=>{
      const L = Math.max(0, parseFloat(load.value || '0'));
      const n = Math.max(1, parseInt(legs.value || '2',10));
      const deg = Math.min(89, Math.max(0, parseFloat(angle.value || '45')));
      const rad = deg * Math.PI / 180;
      const perLeg = L / (n * Math.cos(rad));
      const angleFactor = 1/Math.cos(rad);
      res.innerHTML = `
        <div class="grid">
          <div><b>Angle factor:</b> ${angleFactor.toFixed(3)}</div>
          <div><b>Tension per leg:</b> ${perLeg.toFixed(2)} kg</div>
        </div>
      `;
    };
    btn.addEventListener('click', calc);
    calc();
  }
  if(view==='ar'){
    const status = document.getElementById('xrStatus');
    (async () => {
      if (!('xr' in navigator)) {
        status.innerHTML = '❌ navigator.xr not found — AR not available';
        return;
      }
      try {
        const ok = await navigator.xr.isSessionSupported('immersive-ar');
        status.innerHTML = ok ? '✅ WebXR AR is supported on this device/browser' : '⚠️ WebXR API present but AR session not supported';
      } catch(e){
        status.innerHTML = '⚠️ Could not verify AR support in this context';
      }
    })();
  }
}

document.querySelectorAll('nav button').forEach(btn=>{
  btn.addEventListener('click', e=>{
    document.querySelectorAll('nav button').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    render(btn.dataset.view);
  });
});

render('home');

// PWA service worker registration
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(console.error);
  });
}
